#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sqlite3/sqlite3.h"
#include <stdio.h>
#include <string.h>
#include "Sala.h"



using namespace std;
/*
char itoc(int i) {
     switch (i) {
            case 0: return '0';
            case 1: return '1';
            case 2: return '2';
            case 3: return '3';
            case 4: return '4';
            case 5: return '5';
            case 6: return '6';
            case 7: return '7';
            case 8: return '8';
            case 9: return '9';

     }
}
char* itoa(float f,char saida[]) {

    float valor = f;
    sprintf(saida, "%.3f", valor);
    return saida;
}
char* itoa(int i,char saida[]) {
    int valor = i;
    sprintf(saida, "%d", valor);
    return saida;
}
char* itoa(char*c,char saida[]) {
    char* valor = c;
    sprintf(saida, "%s", valor);
    return saida;
}*/

int arrayTeste[10];
char*** queryResult2;
int cara=0;
static int callback(void *NotUsed, int argc, char **argv, char **azColName){
    int i;

    queryResult2=(char***)realloc(queryResult2,((sizeof (char**))*(cara+1)));
    queryResult2[cara]=(char**)malloc((sizeof (char*))*(argc));
    char** aux=(char**)malloc((sizeof (char*))*(argc));
    for(i=0;i<argc;i++)
    {
        aux[i]=(char*)malloc((sizeof (char))*(50));
        strcpy(aux[i],argv[i]);
        queryResult2[cara][i]=aux[i];
        printf("cpr = %s  %d!!\n", queryResult2[cara][i],cara);
    }
    /*queryResult2[cara]=(char**)malloc((sizeof (char*))*(3));
    char** aux=(char**)malloc((sizeof (char*))*(argc));
    aux[0]=(char*)malloc((sizeof (char))*(50));
    strcpy(aux[0],argv[0]);
    queryResult2[cara][0]=aux[0];
    aux[1]=(char*)malloc((sizeof (char))*(50));
    strcpy(aux[1],argv[1]);
    queryResult2[cara][1]=aux[1];
    printf("cpr = %s  %d!!\n", queryResult2[cara][0],cara);
    printf("cpr = %s  %d!!\n", queryResult2[cara][1],cara);*/

    cara++;
    //queryResult2[0]=queryResult;

   /*for(i=0; i<argc; i++){
        queryResult[i]=argv[i];
        printf("String value = %s\n", queryResult[i]);
   }*/
   //queryResult2=(char***)realloc(queryResult,((sizeof (char**))*50) );
   /*queryResult2[cara]=queryResult;
   printf("tai=%s",queryResult2[cara][1]);
   printf("\n");

   cara++;*/
   return 0;
}
int main(int argc, char* argv[])
{
   sqlite3 *db;
   char *zErrMsg = 0;
   int rc;
   char *sql;

   const char* data = "Callback function called";

   /* Open database */
   rc = sqlite3_open("db.db", &db);
   if( rc ){
      fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
      return(0);
   }else{
      fprintf(stderr, "Opened database successfully\n");
   }






    Sala sala= Sala();
    sala.setId(1);
    sala.setTipo("lokao");
    sala.setNumPoltronas(50);

    sala.cadastrar();

    sala.setId(1);
    sala.setTipo("funfo");
    sala.setNumPoltronas(55);

    sala.alterar();

    sala.setId(1);
    sala.remover();



   /* Create SQL statement */
   sql = "";
  // printf("%s",bb.getQuerySala(sala,s));
     //sql = bb.getQuerySala(sala,s);
   /* Execute SQL statement */
   rc = sqlite3_exec(db, sql, callback, 0, &zErrMsg);
   if( rc != SQLITE_OK ){
      fprintf(stderr, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
   }else{
      fprintf(stdout, "Records created successfully\n");
   }

   /* Create SQL statement */
   sql =
         "SELECT * from sala";

   /* Execute SQL statement */
   /*rc = sqlite3_exec(db, sql, callback, (void*)data, &zErrMsg);
   if( rc != SQLITE_OK ){
      fprintf(stderr, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
   }else{
      fprintf(stdout, "Operation done successfully\n");
   }*/

    bancoCinema bb = bancoCinema();
    //char*** c;
    char***t;
    int l;
    int c;
    bb.execSelectQuery(sql,&t,&l,&c);

    printf("%s\n\n\n",t[2][1]);

    bb.execSelectQuery(sql,&t,&l,&c);

    printf("%s\n",t[3][0]);

    printf("linhas=%d colunas=%d",l,c);


   return 0;
}
