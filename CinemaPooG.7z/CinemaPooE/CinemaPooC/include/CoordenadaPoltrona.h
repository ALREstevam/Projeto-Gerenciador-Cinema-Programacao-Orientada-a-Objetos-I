#ifndef COORDENADAPOLTRONA_H
#define COORDENADAPOLTRONA_H
#include "bancoCinema.h"


class CoordenadaPoltrona
{
    public:
        CoordenadaPoltrona();
        virtual ~CoordenadaPoltrona();
        int getIdCoordenadaPoltrona();
        int getPoltronaFileira();
        int getPoltronaColuna();
        void setIdCoordenadaPoltrona(int idC);
        void setPoltronaFileira(int f);
        void setPoltronaColuna(int c);
        int cadastrar();
        int alterar();
        int remover();

    protected:

    private:
        int idCoordenadaPoltrona;
        int poltronaFileira;
        int poltronaColuna;
        void setQueryInsert(char* query);
        void setQueryUpdate(char* query);
        void setQueryDelete(char* query);
};

#endif // COORDENADAPOLTRONA_H
