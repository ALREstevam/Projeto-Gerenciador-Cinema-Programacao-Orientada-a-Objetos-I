#ifndef FILME_H
#define FILME_H
#include "bancoCinema.h"


class Filme
{
    public:
        Filme();
        virtual ~Filme();
        int getIdFilme();
        char* getNome();
        float getDuracao();
        void setIdFilme(int idF);
        void setNome(char* n);
        void setDuracao(float d);
        int cadastrar();
        int alterar();
        int remover();

    protected:

    private:
        int idFilme;
        char* nome;
        float duracao;
        void setQueryInsert(char* query);
        void setQueryUpdate(char* query);
        void setQueryDelete(char* query);
};

#endif // FILME_H
