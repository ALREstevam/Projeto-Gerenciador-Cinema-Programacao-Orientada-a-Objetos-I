#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sqlite3/sqlite3.h"
#include <stdio.h>
#include <string.h>
#include "Sala.h"
#include "Sessao.h"
#include "Sessao_Poltronas.h"
#include "Poltrona.h"
#include "CoordenadaPoltrona.h"
#include "Filme.h"
#include "Funcionario.h"
#include "Ingresso.h"

using namespace std;

int arrayTeste[10];
char*** queryResult2;
int cara=0;
static int callback(void *NotUsed, int argc, char **argv, char **azColName){
    int i;

    queryResult2=(char***)realloc(queryResult2,((sizeof (char**))*(cara+1)));
    queryResult2[cara]=(char**)malloc((sizeof (char*))*(argc));
    char** aux=(char**)malloc((sizeof (char*))*(argc));
    for(i=0;i<argc;i++)
    {
        aux[i]=(char*)malloc((sizeof (char))*(50));
        strcpy(aux[i],argv[i]);
        queryResult2[cara][i]=aux[i];
        printf("cpr = %s  %d!!\n", queryResult2[cara][i],cara);
    }

    cara++;
   return 0;
}
int main(int argc, char* argv[])
{
   sqlite3 *db;
   char *zErrMsg = 0;
   int rc;
   char *sql;

   const char* data = "Callback function called";

   /* Open database */
   rc = sqlite3_open("db.db", &db);
   if( rc ){
      fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
      return(0);
   }else{
      fprintf(stderr, "Opened database successfully\n");
   }






    Sala sala= Sala();
    sala.setId(1);
    sala.setTipo("lokao");
    sala.setNumPoltronas(50);

    sala.cadastrar();
    sala.setId(2);
    sala.cadastrar();
    sala.setId(3);
    sala.cadastrar();

    Sessao sessao= Sessao();
    sessao.setIdSessao(29);
    sessao.setPrecoBase(17.5f);
    sessao.setIdSala(7);
    sessao.setIdFilme(7);
    sessao.setData("2017/07/25-18:00");
    sessao.cadastrar();

    Sessao_Poltronas sessaoPoltronas= Sessao_Poltronas();
    sessaoPoltronas.setIdSessaoPoltronas(1);
    sessaoPoltronas.setIdSessao(2);
    sessaoPoltronas.setIdPoltrona(2);
    sessaoPoltronas.alterar();

    Poltrona poltrona= Poltrona();
    poltrona.setIdPoltrona(1);
    poltrona.setNumPoltrona(7);
    poltrona.setEstadoOcupada(0);
    poltrona.setIdCoordenada(1);
    poltrona.remover();

    CoordenadaPoltrona coordenadaPoltrona=CoordenadaPoltrona();
    coordenadaPoltrona.setIdCoordenadaPoltrona(2);
    coordenadaPoltrona.setPoltronaFileira(7);
    coordenadaPoltrona.setPoltronaColuna(7);
    coordenadaPoltrona.remover();

    Filme filme =Filme();
    filme.setIdFilme(2);
    filme.setNome("Choice");
    filme.setDuracao(5.70f);
    filme.remover();

    Funcionario funcionario=Funcionario();
    funcionario.setIdFuncionario(2);
    funcionario.setNome("Bruno23");
    funcionario.setLogin("brunoLogin23");
    funcionario.setSenha("brunoSenha23");
    funcionario.setTipo("pedreiro23");
    funcionario.remover();

    Ingresso ingresso= Ingresso();
    ingresso.setIdIngresso(2);
    ingresso.setFormaPgt("cartao23");
    ingresso.setTipo("estudante23");
    ingresso.setIdSessao(123);
    ingresso.setFuncionario(223);
    ingresso.setIdPoltrona(323);
    ingresso.remover();

   /* Create SQL statement */
   sql = "select * from INGRESSO";
   /* Execute SQL statement */
   rc = sqlite3_exec(db,sql, callback, 0, &zErrMsg);
   if( rc != SQLITE_OK ){
      fprintf(stderr, "SQL error: %s\n", zErrMsg);
      sqlite3_free(zErrMsg);
   }else{
      fprintf(stdout, "Records created successfully\n");
   }


   /* Create SQL statement */
   sql =
         "SELECT * from sessao";

    /* Execute SQL statement */
    /* MODO COMO USAR O execSelectQuery:
    bancoCinema bb = bancoCinema();
    //char*** c;
    char***t;
    int l;
    int c;
    bb.execSelectQuery(sql,&t,&l,&c);

    printf("%s\n\n\n",t[0][1]);

    bb.execSelectQuery(sql,&t,&l,&c);

    //printf("%s\n",t[3][0]);

    printf("linhas=%d colunas=%d",l,c);
    */

   return 0;
}
