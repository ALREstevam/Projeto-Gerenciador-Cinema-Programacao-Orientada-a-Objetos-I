#include "Sessao_Poltronas.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

Sessao_Poltronas::Sessao_Poltronas()
{
    //ctor
}

Sessao_Poltronas::~Sessao_Poltronas()
{
    //dtor
}
int Sessao_Poltronas::getIdSessaoPoltronas()
{
    return idSessaoPoltronas;
}
int Sessao_Poltronas::getIdSessao()
{
    return idSessao;
}
int Sessao_Poltronas::getIdPoltrona()
{
    return idPoltrona;
}
void Sessao_Poltronas::setIdSessaoPoltronas(int idSP)
{
    idSessaoPoltronas=idSP;
}
void Sessao_Poltronas::setIdSessao(int idS)
{
    idSessao=idS;
}
void Sessao_Poltronas::setIdPoltrona(int idP)
{
    idPoltrona=idP;
}

void Sessao_Poltronas::setQueryInsert(char* query)
{
    char* queryBegin="INSERT INTO SESSAO_POLTRONAS VALUES (";
    char* queryEnd=");";
    char *arg1=(char*)malloc(sizeof(char)*25);
    char *arg2=(char*)malloc(sizeof(char)*25);
    char *arg3=(char*)malloc(sizeof(char)*25);

    sprintf(arg1, "%d", idSessaoPoltronas);
    sprintf(arg2, "%d", idSessao);
    sprintf(arg3, "%d", idPoltrona);

    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,",");
    strcat(query,arg2);
    strcat(query,",");
    strcat(query,arg3);
    strcat(query,queryEnd);

    free(arg1);
    free(arg2);
    free(arg3);
}
void Sessao_Poltronas::setQueryUpdate(char *query)
{
    char* queryBegin="UPDATE SESSAO_POLTRONAS SET";
    char* queryEnd=";";
    char *arg1=(char*)malloc(sizeof(char)*25);
    char *arg2=(char*)malloc(sizeof(char)*25);
    char *arg3=(char*)malloc(sizeof(char)*25);


    sprintf(arg1, " ID_SESSAO =%d", idSessao);
    sprintf(arg2, " ID_POLTRONA =%d", idPoltrona);
    sprintf(arg3, " WHERE ID_SESSAOPOLTRONAS =%d", idSessaoPoltronas);

    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,",");
    strcat(query,arg2);
    strcat(query,arg3);

    strcat(query,queryEnd);
    free(arg1);
    free(arg2);
    free(arg3);
}
void Sessao_Poltronas::setQueryDelete(char* query)
{
    char* queryBegin="DELETE FROM SESSAO_POLTRONAS WHERE ID_SESSAOPOLTRONAS =";
    char* queryEnd=";";
    char *arg1=(char*)malloc(sizeof(char)*25);
    sprintf(arg1, " %d", idSessaoPoltronas);

    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,queryEnd);

    free(arg1);
}
int Sessao_Poltronas::cadastrar()
{

    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryInsert(c);
    return bc.execQuery(c);
}
int Sessao_Poltronas::alterar()
{
    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryUpdate(c);
    return bc.execQuery(c);
}
int Sessao_Poltronas::remover()
{
    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryDelete(c);
    return bc.execQuery(c);
}
