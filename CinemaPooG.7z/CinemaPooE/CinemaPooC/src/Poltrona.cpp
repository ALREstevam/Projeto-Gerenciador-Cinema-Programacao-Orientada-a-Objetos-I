#include "Poltrona.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

Poltrona::Poltrona()
{
    //ctor
}

Poltrona::~Poltrona()
{
    //dtor
}
int Poltrona::getIdPoltrona()
{
    return idPoltrona;
}
int Poltrona::getNumPoltrona()
{
    return numPoltrona;
}
int Poltrona::getEstadoOcupada()
{
    return estadoOcupada;
}
int Poltrona::getIdCoordenada()
{
    return idCoordenada;
}
void Poltrona::setIdPoltrona(int idP)
{
    idPoltrona=idP;
}
void Poltrona::setNumPoltrona(int nP)
{
    numPoltrona=nP;
}
void Poltrona::setEstadoOcupada(int e)
{
    estadoOcupada=e;
}
void Poltrona::setIdCoordenada(int idC)
{
    idCoordenada=idC;
}

void Poltrona::setQueryInsert(char* query)
{
    char* queryBegin="INSERT INTO POLTRONA VALUES (";
    char* queryEnd=");";
    char *arg1=(char*)malloc(sizeof(char)*25);
    char *arg2=(char*)malloc(sizeof(char)*25);
    char *arg3=(char*)malloc(sizeof(char)*25);
    char *arg4=(char*)malloc(sizeof(char)*25);

    sprintf(arg1, "%d", idPoltrona);
    sprintf(arg2, "%d", numPoltrona);
    sprintf(arg3, "%d", estadoOcupada);
    sprintf(arg4, "%d", idCoordenada);

    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,",");
    strcat(query,arg2);
    strcat(query,",");
    strcat(query,arg3);
    strcat(query,",");
    strcat(query,arg4);
    strcat(query,queryEnd);

    free(arg1);
    free(arg2);
    free(arg3);
    free(arg4);

    printf("%s",query);
}
void Poltrona::setQueryUpdate(char *query)
{
    char* queryBegin="UPDATE POLTRONA SET";
    char* queryEnd=";";
    char *arg1=(char*)malloc(sizeof(char)*25);
    char *arg2=(char*)malloc(sizeof(char)*25);
    char *arg3=(char*)malloc(sizeof(char)*25);
    char *arg4=(char*)malloc(sizeof(char)*25);


    sprintf(arg1, " NUMPOLTRONA =%d", numPoltrona);
    sprintf(arg2, " ESTADOOCUPADA =%d", estadoOcupada);
    sprintf(arg3, " COORDENADA =%d", idCoordenada);
    sprintf(arg4, " WHERE ID_POLTRONA =%d", idPoltrona);

    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,",");
    strcat(query,arg2);
    strcat(query,",");
    strcat(query,arg3);
    strcat(query,arg4);
    strcat(query,queryEnd);

    printf("%s",query);
    free(arg1);
    free(arg2);
    free(arg3);
    free(arg4);
}
void Poltrona::setQueryDelete(char* query)
{
    char* queryBegin="DELETE FROM POLTRONA WHERE ID_POLTRONA =";
    char* queryEnd=";";
    char *arg1=(char*)malloc(sizeof(char)*25);
    sprintf(arg1, " %d", idPoltrona);

    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,queryEnd);

    free(arg1);
}
int Poltrona::cadastrar()
{
    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryInsert(c);
    return bc.execQuery(c);
}
int Poltrona::alterar()
{
    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryUpdate(c);
    return bc.execQuery(c);
}
int Poltrona::remover()
{
    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryDelete(c);
    return bc.execQuery(c);
}
