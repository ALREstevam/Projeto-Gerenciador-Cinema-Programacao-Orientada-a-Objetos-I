#include "Sessao.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

Sessao::Sessao()
{
    //ctor
}

Sessao::~Sessao()
{
    //dtor
}
int Sessao::getIdSessao()
{
    return idSessao;
}
float Sessao::getPrecoBase()
{
    return precoBase;
}
int Sessao::getIdSala()
{
    return idSala;
}
int Sessao::getIdFilme()
{
    return idFilme;
}
char* Sessao::getData()
{
    return data;
}
void Sessao::setIdSessao(int idS)
{
    idSessao=idS;
}
void Sessao::setPrecoBase(int pb)
{
    precoBase=pb;
}
void Sessao::setIdSala(int s)
{
    idSala=s;
}
void Sessao::setIdFilme(int f)
{
    idFilme=f;
}
void Sessao::setData(char* d)
{
    data=d;
}
void Sessao::setQueryInsert(char* query)
{
    //char *query;
    char* queryBegin="INSERT INTO SESSAO VALUES (";
    char* queryEnd=");";
     char *arg1=(char*)malloc(sizeof(char)*25);
    char *arg2=(char*)malloc(sizeof(char)*25);
    char *arg3=(char*)malloc(sizeof(char)*25);
    char *arg4=(char*)malloc(sizeof(char)*25);
    char *arg5=(char*)malloc(sizeof(char)*25);

    sprintf(arg1, "%d", idSessao);
    sprintf(arg2, "'%f'", precoBase);
    sprintf(arg3, "%d", idSala);
    sprintf(arg4, "%d", idFilme);
    sprintf(arg5, "'%s'", data);

    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,",");
    strcat(query,arg2);
    strcat(query,",");
    strcat(query,arg3);
    strcat(query,",");
    strcat(query,arg4);
    strcat(query,",");
    strcat(query,arg5);
    strcat(query,queryEnd);

    free(arg1);
    free(arg2);
    free(arg3);
    free(arg4);
    free(arg5);

}
void Sessao::setQueryUpdate(char* query)
{
    //char *query;
    char* queryBegin="UPDATE SESSAO SET";
    char* queryEnd=";";
    char *arg1=(char*)malloc(sizeof(char)*25);
    char *arg2=(char*)malloc(sizeof(char)*25);
    char *arg3=(char*)malloc(sizeof(char)*25);
    char *arg4=(char*)malloc(sizeof(char)*25);
    char *arg5=(char*)malloc(sizeof(char)*25);


    sprintf(arg1, " PRECOBASE =%f", precoBase);
    sprintf(arg2, " ID_SALA =%d", idSala);
    sprintf(arg3, " ID_FILME =%d", idFilme);
    sprintf(arg4, " DTTIME ='%s'", data);
    sprintf(arg5, " WHERE ID_SESSAO =%d", idSessao);

    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,",");
    strcat(query,arg2);
    strcat(query,",");
    strcat(query,arg3);
    strcat(query,",");
    strcat(query,arg4);
    strcat(query,arg5);

    strcat(query,queryEnd);
    free(arg1);
    free(arg2);
    free(arg3);
    free(arg4);
    free(arg5);
}
void Sessao::setQueryDelete(char* query)
{
    //char *query;
    char* queryBegin="DELETE FROM SESSAO WHERE ID_SESSAO =";
    char* queryEnd=";";
    char *arg1=(char*)malloc(sizeof(char)*25);
    sprintf(arg1, " %d", idSessao);

    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,queryEnd);

    free(arg1);
}
int Sessao::cadastrar()
{

    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryInsert(c);
    return bc.execQuery(c);
}
int Sessao::alterar()
{
    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryUpdate(c);
    return bc.execQuery(c);
}
int Sessao::remover()
{
    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryDelete(c);
    return bc.execQuery(c);
}
