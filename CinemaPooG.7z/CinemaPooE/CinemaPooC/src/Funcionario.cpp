#include "Funcionario.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


Funcionario::Funcionario()
{
    //ctor
}

Funcionario::~Funcionario()
{
    //dtor
}
int Funcionario::getIdFuncionario()
{
    return idFuncionario;
}
char* Funcionario::getNome()
{
    return nome;
}
char* Funcionario::getLogin()
{
    return login;
}
char* Funcionario::getSenha()
{
    return senha;
}
char* Funcionario::getTipo()
{
    return tipo;
}
void Funcionario::setIdFuncionario(int idF)
{
    idFuncionario=idF;
}
void Funcionario::setNome(char* n)
{
    nome=n;
}
void Funcionario::setLogin(char* l)
{
    login=l;
}
void Funcionario::setSenha(char* s)
{
    senha=s;
}
void Funcionario::setTipo(char* t)
{
    tipo=t;
}

void Funcionario::setQueryInsert(char* query)
{

    char* queryBegin="INSERT INTO FUNCIONARIO VALUES (";
    char* queryEnd=");";
     char *arg1=(char*)malloc(sizeof(char)*50);
    char *arg2=(char*)malloc(sizeof(char)*50);
    char *arg3=(char*)malloc(sizeof(char)*50);
    char *arg4=(char*)malloc(sizeof(char)*50);
    char *arg5=(char*)malloc(sizeof(char)*50);

    sprintf(arg1, "%d", idFuncionario);
    sprintf(arg2, "'%s'", nome);
    sprintf(arg3, "'%s'", login);
    sprintf(arg4, "'%s'", senha);
    sprintf(arg5, "'%s'", tipo);

    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,",");
    strcat(query,arg2);
    strcat(query,",");
    strcat(query,arg3);
    strcat(query,",");
    strcat(query,arg4);
    strcat(query,",");
    strcat(query,arg5);
    strcat(query,queryEnd);

    free(arg1);
    free(arg2);
    free(arg3);
    free(arg4);
    free(arg5);
}
void Funcionario::setQueryUpdate(char* query)
{
    char* queryBegin="UPDATE FUNCIONARIO SET";
    char* queryEnd=";";
    char *arg1=(char*)malloc(sizeof(char)*50);
    char *arg2=(char*)malloc(sizeof(char)*50);
    char *arg3=(char*)malloc(sizeof(char)*50);
    char *arg4=(char*)malloc(sizeof(char)*50);
    char *arg5=(char*)malloc(sizeof(char)*50);


    sprintf(arg1, " NOME ='%s'", nome);
    sprintf(arg2, " LOGIN ='%s'", login);
    sprintf(arg3, " SENHA ='%s'", senha);
    sprintf(arg4, " TIPO ='%s'", tipo);
    sprintf(arg5, " WHERE ID_FUNCIONARIO =%d", idFuncionario);


    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,",");
    strcat(query,arg2);
    strcat(query,",");
    strcat(query,arg3);
    strcat(query,",");
    strcat(query,arg4);
    strcat(query,arg5);

    strcat(query,queryEnd);
    free(arg1);
    free(arg2);
    free(arg3);
    free(arg4);
    free(arg5);
}
void Funcionario::setQueryDelete(char* query)
{

    char* queryBegin="DELETE FROM FUNCIONARIO WHERE ID_FUNCIONARIO =";
    char* queryEnd=";";
    char *arg1=(char*)malloc(sizeof(char)*25);
    sprintf(arg1, " %d", idFuncionario);

    strcpy(query,queryBegin);
    strcat(query,arg1);
    strcat(query,queryEnd);

    free(arg1);

}
int Funcionario::cadastrar()
{

    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryInsert(c);
    return bc.execQuery(c);
}
int Funcionario::alterar()
{
    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryUpdate(c);
    return bc.execQuery(c);
}
int Funcionario::remover()
{
    bancoCinema bc =bancoCinema();
    char c[200];
    setQueryDelete(c);
    return bc.execQuery(c);
}
